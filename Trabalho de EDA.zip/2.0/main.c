#include "arq.h"
#include "math.h"

int main()
{	
	struct descF *p = cria(sizeof(info));

	info i;

	i.idade = 10;
	insere(&i, p);

	i.idade = 12;
	insere(&i, p);

	i.idade = 9;
	insere(&i, p);

	i.idade = 13;
	insere(&i, p);

	while(!testaVazia(p)) {
		remove_(&i, p);
		printf("%d\n", i.idade);
	}

	p=destroi(p);

  return 0;
}
 
